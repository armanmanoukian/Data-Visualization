library(shinydashboard)
library(shinyWidgets)
library(dplyr)
library(magrittr)
library(ggplot2)
library(plotly)
library(ggthemes)
library(viridis)  
library(RColorBrewer)
library(data.table)
library(summarytools)
library(parameters)
library(DT)
library(descriptr)
library(dashboardthemes)


# importing data ----
df <- read.csv("output_df.csv")
df$Date <- as.Date(df$Date, format = "%Y-%m-%d")
df[sapply(df, is.character)] <- lapply(df[sapply(df, is.character)], 
                                       as.factor)

df <- df %>% select(-c('hr'))

name_to_cols <- function(columns) {
    output_columns = c()
    for (col in columns) {
        if (col == 'Season') {
            output_columns = c(output_columns, 'season')
        } else if (col == 'Holiday') {
            output_columns = c(output_columns, 'holiday')
        } else if (col == 'Working Day') {
            output_columns = c(output_columns, 'workingday')
        } else if (col == 'Weather') {
            output_columns = c(output_columns, 'weather')
        } else if (col == 'Temperature Feeling') {
            output_columns = c(output_columns, 'atemp')
        } else if (col == 'Humidity') {
            output_columns = c(output_columns, 'humidity')
        } else if (col == 'Wind Speed') {
            output_columns = c(output_columns, 'windspeed')
        } else if (col == 'Day Time') {
            output_columns = c(output_columns, 'Day_Time')
        }
    } 
    return(output_columns)
}

cols_to_names = function(columns) {
    output_columns = c()
    for (col in columns) {
        if (col == '(Intercept)') {
            output_columns = c(output_columns, 'Intercept')
        } else if (col == 'seasonspring') {
            output_columns = c(output_columns, 'Season: Spring')
        } else if (col == 'seasonsummer') {
            output_columns = c(output_columns, 'Season: Summer')
        } else if (col == 'seasonwinter') {
            output_columns = c(output_columns, 'Season: Winter')
        } else if (col == 'holidayNot holiday') {
            output_columns = c(output_columns, 'Not Holiday')
        } else if (col == 'workingdayWorkday') {
            output_columns = c(output_columns, 'Workday')
        } else if (col == 'weatherHeavy Rain') {
            output_columns = c(output_columns, 'Weather: Heavy Rain')
        } else if (col == 'weatherLight Snow') {
            output_columns = c(output_columns, 'Weather: Light Snow')
        } else if (col == 'weatherMist') {
            output_columns = c(output_columns, 'Weather: Mist')
        } else if (col == 'atemp') {
            output_columns = c(output_columns, 'Temperature Feeling')
        } else if (col == 'humidity') {
            output_columns = c(output_columns, 'Humidity')
        } else if (col == 'windspeed') {
            output_columns = c(output_columns, 'Wind Speed')
        } else if (col == 'Day_TimeSleep time') {
            output_columns = c(output_columns, 'Day Time: Sleep time')
        } else if (col == 'Day_TimeWork time') {
            output_columns = c(output_columns, 'Day Time: Work time	')
        }
    } 
    return(output_columns)
}
vector1 = c('(Intercept)', 'seasonspring', 'seasonsummer', 'seasonwinter', 'holidayNot holiday',
            'workingdayWorkday', 'weatherHeavy Rain', 'weatherLight Snow', 'weatherMist',
            'atemp', 'humidity', 'windspeed', 'Day_TimeSleep time', 'Day_TimeWork time')


categorical_cols = c('season', 'holiday',
                     'workingday', 'weather', 'Day_Time')

categorical_names = c('Season', 'Holiday',
                      'Working Day', 'Weather','Day Time')

numeric_cols = c('atemp', 'humidity',
                 'windspeed', 'Count')

numeric_names = c('Temperature Feeling', 'Humidity',
                  'Wind Speed', 'Count')

cols = colnames(df[,!colnames(df) %in% c("Count","Date")])
col_names <- c('Season', 'Holiday', 'Working Day', 'Weather', 'Temperature Feeling',
              'Humidity', 'Wind Speed', 'Day Time')
# Define UI for application that draws a histogram
header = dashboardHeader(
    title = "Bike-Sharing"
)
sidebar = dashboardSidebar(
    sidebarMenu(
        menuItem("About",
                 tabName = 'about'),
        menuItem("Visualization",
                 tabName = 'eda'),
        menuItem("Summary Table",
                 tabName = 'summary_table'),
        menuItem("Model",
                 tabName = 'model')
    )
)

body = dashboardBody(
    shinyDashboardThemes(
        theme = "purple_gradient"
    ),
    tabItems(
        tabItem(tabName = 'about',
                imageOutput('image'),
                textOutput("About1"),
                textOutput("About2"),
                textOutput("About3"),
                textOutput("About4"),
                textOutput("About5"),
                textOutput("About6"),
                textOutput("About7"),
                textOutput("About8"),
                textOutput("About9"),
                textOutput("About10"),
                textOutput("About11"),
                textOutput("About12"),
                textOutput("About13"),
                textOutput("About14"),
                textOutput("About15"),
                textOutput("Authors"),
                tags$head(tags$style("#About1{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-top: -320px;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About2{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About3{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About4{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About5{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 height: 50px;
                                 }")),
                tags$head(tags$style("#About6{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About7{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About8{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About9{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About10{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About11{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 height: 50px;
                                 }")),
                tags$head(tags$style("#About12{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About13{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About14{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#About15{color: black;
                                 font-size: 13.5px;
                                 font-style: oblique;
                                 margin-left: 20px;
                                 }")),
                tags$head(tags$style("#Authors{color: white;
                                 font-size: 20px;
                                 font-style: italic;
                                 margin-top: 250px;
                                 margin-left: 20px;
                                 }"))
        ),
        tabItem(tabName = 'eda',
                tabsetPanel(
                    tabPanel("Boxplot",
                             sidebarLayout(
                                 sidebarPanel(
                                     radioGroupButtons(
                                         inputId = "boxplot_x",
                                         label = "X-axis",
                                         choiceNames = categorical_names,
                                         choiceValues = categorical_cols
                                     ),
                                     radioGroupButtons(
                                         inputId = "boxplot_y",
                                         label = "Y-axis",
                                         choiceNames = numeric_names,
                                         choiceValues = numeric_cols
                                     ),
                                     radioGroupButtons(
                                         inputId = "boxplot_c",
                                         label = "Color",
                                         choiceNames = categorical_names,
                                         choiceValues = categorical_cols
                                     ),
                                     dateRangeInput("boxplot_date",
                                                    "Choose date range",
                                                    start = min(df$Date),
                                                    end = max(df$Date),
                                                    min = min(df$Date),
                                                    max = max(df$Date)
                                     )
                                 ),
                                 mainPanel(plotOutput('boxplot'))
                             )
                    ),
                    tabPanel("Barplot",
                             sidebarLayout(
                                 sidebarPanel(
                                     radioGroupButtons(
                                         inputId = "barplot_x",
                                         label = "X-axis",
                                         choiceNames = categorical_names,
                                         choiceValues = categorical_cols
                                     ),
                                     radioGroupButtons(
                                         inputId = "barplot_c",
                                         label = "Color",
                                         choiceNames = categorical_names,
                                         choiceValues = categorical_cols
                                     ),
                                     dateRangeInput("barplot_date",
                                                    "Choose date range",
                                                    start = min(df$Date),
                                                    end = max(df$Date),
                                                    min = min(df$Date),
                                                    max = max(df$Date)
                                     ),
                                     prettyRadioButtons(
                                         inputId = "barplot_count_type",
                                         label = "Y-axis:", 
                                         choices = c("Count", "Percentage"),
                                         icon = icon("check"),
                                         animation = "jelly"
                                     )
                                 ),
                                 mainPanel(plotOutput('barplot'))
                             )
                    ),
                    tabPanel("Histogram",
                             sidebarLayout(
                                 sidebarPanel(
                                     radioGroupButtons(
                                         inputId = "histogram_x",
                                         label = "X-axis",
                                         choiceNames = numeric_names,
                                         choiceValues = numeric_cols
                                     ),
                                     radioGroupButtons(
                                         inputId = "histogram_c",
                                         label = "Color",
                                         choiceNames = categorical_names,
                                         choiceValues = categorical_cols
                                     ),
                                     dateRangeInput("histogram_date",
                                                    "Choose date range",
                                                    start = min(df$Date),
                                                    end = max(df$Date),
                                                    min = min(df$Date),
                                                    max = max(df$Date)
                                     ),
                                     sliderInput("range", "Bins:",
                                                 min = 1, max = 100,
                                                 value = 50)
                                     # awesomeCheckboxGroup(
                                     #     inputId = "histogram_statistics",
                                     #     label = "Statistics", 
                                     #     choices = c("Mean", "Median", "Variance"),
                                     #     selected = "Mean",
                                     #     inline = TRUE, 
                                     #     status = "warning"
                                     # )
                                 ),
                                 mainPanel(plotOutput('histogram'))
                             )
                    )
                )
        ),
        tabItem(tabName = 'model',
                sidebarLayout(
                    sidebarPanel(
                        selectInput(
                            "model_type",
                            "Choose a model",
                            c('Linear Regression', 'Poisson Regression', 
                              'Quasi-Poisson Regression', 'Negative Binomial Regression')),
                        
                        pickerInput(
                            inputId = "model_columns",
                            label = "Choose columns for the model", 
                            choices = col_names,
                            selected = col_names,
                            options = list(
                                `actions-box` = TRUE), 
                            multiple = TRUE
                        ),
                        dateRangeInput("model_date",
                                       "Choose date range",
                                       start = min(df$Date),
                                       end = max(df$Date),
                                       min = min(df$Date),
                                       max = max(df$Date)
                        ),radioGroupButtons(
                            inputId = "facet_resids",
                            label = "Split residuals",
                            choiceNames = categorical_names,
                            choiceValues = categorical_cols
                        ),
                        downloadButton("report", "Generate report")
                    ),
                    mainPanel(
                        tableOutput("model_summary"),
                        plotOutput("residuals_histogram")
                    )
                )
        ),
        tabItem(
            tabName = 'summary_table',
            sidebarLayout(
                sidebarPanel(
                    radioGroupButtons(
                        inputId = "summary_value",
                        label = "Summarise Value", 
                        choiceNames = numeric_names,
                        choiceValues = numeric_cols,
                        status = "danger"
                    ),
                    radioGroupButtons(
                        inputId = "group_by",
                        label = "Group by", 
                        choiceNames = categorical_names,
                        choiceValues = categorical_cols,
                        status = "danger"
                    ),
                    dateRangeInput("summary_date",
                                   "Choose date range",
                                   start = min(df$Date),
                                   end = max(df$Date),
                                   min = min(df$Date),
                                   max = max(df$Date)
                    )
                ),
                mainPanel(
                    dataTableOutput("Summary_statistics")
                    )
            )
        )
    ),
    bookmarkButton()
)


ui <- dashboardPage(header, sidebar, body)


server <- function(input, output) {
    output$About1 <- renderText({
        
        "Bike sharing systems are new generation of traditional bike rentals where whole process from membership, " 
    })
    
    output$About2 = renderText({
        "rental and return back has become automatic. Through these systems, user is able to easily rent a bike from "
    })
    
    output$About3 = renderText({
        " a particular position and return back at another position. Currently, there are about over 500 bike-sharing" 
    })
    
    output$About4 = renderText({
        "programs around the world which is composed of over 500 thousands bicycles. Today, there exists great interest"
    })
    
    output$About5 = renderText({
        " in these systems due to their important role in traffic, environmental and health issues."
    })
    
    output$About6 = renderText({
        "Apart from interesting real world applications of bike sharing systems, the characteristics of data being "
    })
    
    output$About7 = renderText({
        " generated by these systems make them attractive for the research. Opposed to other transport services such"
    })
    
    output$About8 = renderText({
        " as bus or subway, the duration of travel, departure and arrival position is explicitly recorded in these"
    })
    
    output$About9 = renderText({
        " systems. This feature turns bike sharing system into a virtual sensor network that can be used for sensing"
    })
    
    output$About10 = renderText({
        " mobility in the city. Hence, it is expected that most of important events in the city could be detected via monitoring these data."
    })
    
    output$About11 = renderText({
        "The goal of this study is to understand the relationship between the number of bike-sharing services provided"
    })
    
    output$About12 = renderText({
        " and different factors described in the data. This will help the bike-sharing company to make informative"
    })
    
    output$About13 = renderText({
        "decisions about the number of bikes needed to be held in stock. It will also be helpful for the company"
    })
    
    output$About14 = renderText({
        " to make predictions about sales (e.g., for different seasons)."
    })
    
    output$Authors = renderText({
        "By Marianna Ghazaryan, Gurgen Hovakimyan, Seyran Minasyan"
    })
    
    output$image = renderImage(
        list(
            src = "bike_sharing.jpg",
            contentType = "image/jpg",
            width = "100%", height = "730px"
        )
    )
    
    
    output$boxplot <- renderPlot({
        df_cutted_boxplot = df %>% filter(Date >= input$boxplot_date[1], Date <= input$boxplot_date[2])
        ggplot(df_cutted_boxplot, aes(x = df_cutted_boxplot[,input$boxplot_x],
                                      y = df_cutted_boxplot[,input$boxplot_y],
                                      fill = df_cutted_boxplot[,input$boxplot_c])) + 
            geom_boxplot() +
            theme_bw() + 
            labs(x = input$boxplot_x, y = input$boxplot_y, fill = input$boxplot_c,
                 title = paste0("Boxplot of ", input$boxplot_y, " separated by ",
                                input$poxplot_x, " and ", input$boxplot_c)) +
            scale_fill_brewer(palette = "Set1")
    })
    output$barplot <- renderPlot({
        df_cutted_barplot = df %>%
            filter(Date >= input$barplot_date[1], Date <= input$barplot_date[2])
        if (input$barplot_count_type == 'Percentage') {
           
            ggplot(df_cutted_barplot, aes(x = df_cutted_barplot[, input$barplot_x],
                                          fill = df_cutted_barplot[,input$barplot_c])) + 
                geom_bar(aes(y = (..count..)/sum(..count..)), position = 'dodge') +
                theme_bw() + 
                labs(x = input$barplot_x, y = input$barplot_y, fill = input$barplot_c,
                     title = paste0("Barplot of ", input$barplot_x, " separated by ",
                                    input$barplot_c)) +
                scale_fill_brewer(palette = "Set1")
        } else if (input$barplot_count_type == "Count") {
            ggplot(df_cutted_barplot, aes(x = df_cutted_barplot[, input$barplot_x],
                                          fill = df_cutted_barplot[, input$barplot_c])) + 
                geom_bar(position = 'dodge') +
                theme_bw() + 
                labs(x = input$barplot_x, y = input$barplot_y, fill = input$barplot_c,
                     title = paste0("Barplot of ", input$barplot_x, " separated by ",
                                    input$barplot_c)) +
                scale_fill_brewer(palette = "Set1") 
        }
        
    })
    output$histogram <- renderPlot({
            df_cutted_histogram = df %>%
                filter(Date >= input$histogram_date[1], Date <= input$histogram_date[2])
            ggplot(df_cutted_histogram, aes(x = df_cutted_histogram[,input$histogram_x],
                                            fill = df_cutted_histogram[,input$histogram_c])) +
                facet_wrap(.~ df_cutted_histogram[,input$histogram_c], scale = "free") +
                geom_histogram(bins = input$range) +
                theme_bw() + 
                labs(x = input$histogram_x, fill = input$histogram_c,
                     title = paste0("Histogram of ", input$histogram_x, " seperated by ",
                                    input$histogram_c)) +
                scale_fill_viridis(discrete = TRUE)
        
    })
    
    output$model_summary <- renderTable({
        model_columns <- name_to_cols(input$model_columns)
        df_selected <- df[, c("Count", model_columns, "Date")] %>% 
            filter(Date >= input$barplot_date[1], Date <= input$barplot_date[2])
        if (input$model_type == 'Linear Regression') {
            model <- lm(Count ~.-Date, data =  df_selected)
        }

        else if (input$model_type == 'Poisson Regression') {
           model <- glm(Count ~.-Date , data = df_selected,
                        family = "poisson")
        } else if (input$model_type == 'Quasi-Poisson Regression') {
            model <- glm(Count~.-Date, data = df_selected,
                         family = "quasipoisson")
        } else if (input$model_type == 'Negative Binomial Regression') {
            model <- MASS::glm.nb(Count~.-Date, data = df_selected)
        }
        model_param <- parameters(model) %>% as.data.frame() %>% select(!c("df_error"))
        model_param$Parameter <- cols_to_names(model_param$Parameter)
        model_param
    })
    
    output$residuals_histogram <- renderPlot({
        model_columns <- name_to_cols(input$model_columns)
        df_selected <- df[, c("Count", model_columns, "Date")] %>% 
            filter(Date >= input$barplot_date[1], Date <= input$barplot_date[2])
        if (input$model_type == 'Linear Regression') {
            model <- lm(Count ~.-Date, data =  df_selected)
        }
        
        else if (input$model_type == 'Poisson Regression') {
            model <- glm(Count ~.-Date , data = df_selected,
                         family = "poisson")
        } else if (input$model_type == 'Quasi-Poisson Regression') {
            model <- glm(Count~.-Date, data = df_selected,
                         family = "quasipoisson")
        } else if (input$model_type == 'Negative Binomial Regression') {
            model <- MASS::glm.nb(Count~.-Date, data = df_selected)
        }
        if (input$model_type == 'Linear Regression') {
            plot_data <- data.frame(Residuals = model$residuals,
                                    Fitted_Values = model$fitted.values,
                                    Color = df_selected[, input$facet_resids])
            ggplot(data = plot_data, aes(x = Residuals,
                                         fill = Color)) +
                geom_histogram() +
                labs(fill = input$facet_resids, x = "Residuals", y = "Count",
                     title = "Residuals histogram") +
                facet_wrap(.~df_selected[, input$facet_resids], scale = "free") + 
                theme_bw() + 
                scale_fill_brewer(palette = "Dark2")
        } else {
            plot_data <- data.frame(Residuals = resid(model, type = "pearson"),
                                    Fitted_Values = model$fitted.values,
                                    Color = df_selected[, input$facet_resids])
            ggplot(data = plot_data, aes(x = Fitted_Values,
                                         y = Residuals, color = Color)) +
                geom_point() +
                labs(color = input$facet_resids, x = "Fitted values", y = "Pearson Residuals",
                     title = "Pearson Residuals vs Fitted values") +
                facet_wrap(.~df_selected[, input$facet_resids], scale = "free") + 
                theme_bw() + 
                scale_color_brewer(palette = "Dark2")
        }
    })
    
    output$Summary_statistics <- renderDT({
        df_summary <- df %>%
            filter(Date >= input$summary_date[1], Date <= input$summary_date[2])
        summary_data <- 
            data.frame(Mean = tapply(df_summary[, input$summary_value],
                                     df_summary[, input$group_by], mean),
                       Median = tapply(df_summary[, input$summary_value],
                                       df_summary[, input$group_by], median),
                       `Standard Deviation` = tapply(df_summary[, input$summary_value],
                                                     df_summary[, input$group_by], sd),
                       `First Quantile` = tapply(df_summary[, input$summary_value],
                                                 df_summary[, input$group_by], quantile, 0.25),
                       `Third Quantile` = tapply(df_summary[, input$summary_value],
                                                 df_summary[, input$group_by], quantile, 0.75),
                       Minimum = tapply(df_summary[, input$summary_value],
                                        df_summary[, input$group_by], min),
                       Maximum = tapply(df_summary[, input$summary_value],
                                        df_summary[, input$group_by], max),
                       row.names = unique(df_summary[, input$group_by]))
        apply(summary_data, 2, round, 2)
        
    })
    
    output$report <- downloadHandler(
        filename = "report.html",
        content = function(file) {
            tempReport <- file.path(normalizePath(getwd()), "generated_report.Rmd")
            #file.copy("generated_report.Rmd", tempReport, overwrite = TRUE)
            params <- list(
                facet = input$facet_resids,
                type = input$model_type,
                date = input$model_date,
                columns = input$model_columns
            )
            rmarkdown::render(tempReport, output_file = file,
                              params = params,
                              envir = new.env(parent = globalenv())
            )
        }
    )
    
    
}
enableBookmarking(store = "url")
# Run the application 
shinyApp(ui = ui, server = server)


