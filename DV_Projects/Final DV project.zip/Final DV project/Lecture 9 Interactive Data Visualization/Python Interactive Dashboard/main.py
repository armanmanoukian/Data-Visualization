import dash
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output, State
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import plotly.io as pio
import numpy as np
import plotly.figure_factory as ff
import statsmodels.api as sm
from sklearn.preprocessing import OrdinalEncoder


# Load the data from the XLSX file
data = pd.read_excel('house_data.xlsx')

plot_data = pd.DataFrame()

columns_to_drop = ['date']
df = data.drop(columns=columns_to_drop)

df['sqm'] = df['sqm'].str.replace('Ք.Մ.', '')
df['rooms'] = df['rooms'].str.replace('Սեն','')
df['floors'] = df['floors'].str.replace('Հարկ','')
df['floors'] = df['floors'].str.split('/').str[0]
df['price'] = df['price'].str.replace(',', '')
df['address'] = df['address'].str.split(', ', expand=True)[1]

for i in range(len(df)):
    if df['rooms'].iloc[i] == "7+":
        df['rooms'].iloc[i] = "7"

df['price'] = df['price'].astype('float')
df['Lprice'] = np.log(df['price'])
df['sqm'] = df['sqm'].astype('float')
df['rooms'] = df['rooms'].astype('int')
df['floors'] = df['floors'].astype('int')

view_data = df.head(10)


########## styling
app = dash.Dash(__name__, suppress_callback_exceptions=True)
custom_tabs_container = {
    'width': '85%'
}
custom_tabs = {
    'border-top-left-radius': '3px',
    'background-color': '#f9f9f9',
    'padding': '0px 24px',
    'border-bottom': '1px solid #d6d6d6'
}
custom_tab = {
    'color': '#111111',
    'border - top - left - radius': '3 px',
    'border - top - right - radius': '3 px',
    'border - top': '3 px solid transparent !important',
    'border - left': '0 px !important',
    'border - right': '0 px !important',
    'border - bottom': '0 px !important',
    'background - color': '#fafbfc',
    'padding': '12 px !important',
    'font - family': "system-ui",
    'display': 'flex !important',
    'align - items': 'center',
    'justify - content': 'center',
}
custom_tab_selected = {
    'color': 'black',
    'box-shadow': '1px 1px 0px white',
    'border-left': '1px solid lightgrey !important',
    'border-right': '1px solid lightgrey !important',
    'border-top': '3px solid #e36209 ',
    # 'background - color': 'red'

}

########## Tabs
app.layout = html.Div([
    dcc.Tabs(id="tabs-styled-with-inline",
             value='tab-1',
             parent_className='custom-tabs',
             children=[
                 dcc.Tab(label='About', value='tab-1', style=custom_tab, selected_style=custom_tab_selected),
                 dcc.Tab(label='Data Visualization', value='tab-2', style=custom_tab, selected_style=custom_tab_selected),
                 dcc.Tab(label='Regression Model', value='tab-3', style=custom_tab, selected_style=custom_tab_selected),
             ]),
    html.Div(id='tabs-content-inline')
    ],
    style={'background': '#111111'}
)


@app.callback(Output('tabs-content-inline', 'children'),
              Input('tabs-styled-with-inline', 'value'))
def render_content(tab):
    ########### Tab 1
    if tab == 'tab-1':
        return html.Div([
            html.Br(),

            html.P(
                'The problem is to detect how different factors affect price changes of apartments in Yerevan. '),

            html.P(
                'The problem is chosen as we are live in Yerevan and apartments prices correct prediction will help us to choose correct apartment in the future.'),
            html.P(
                'This application can use house agencies and people that live in Yerevan'),

            html.P(
                'We have scrapped data from my realty website. It is stored as local file. If we scrap again it will update the existing data. '),

            html.P(
                'Anyone who has an interest in the field of financial investments including “newcomers”, experts, analysts etc.'
            ),
            html.Label("Yerevan House Price", style={'fontSize': 36, 'font-style': 'normal'}),
            html.Br(),
            html.Br(),
            dash_table.DataTable(
                id='table',
                columns=[{"name": i, "id": i} for i in view_data.columns],
                data=view_data.to_dict('records'),
                style_cell={'backgroundColor': '#111111', 'textAlign': 'center', 'fontSize': 14,
                            'font-style': 'normal'},
                sort_action="native"
            )
        ],
            style={'color': '#ffffff', 'fontSize': 20, 'textAlign': 'center', 'font-style': 'italic'})
    ########### Tab 2
    elif tab == 'tab-2':
        return html.Div([
            html.Div([
                dcc.Dropdown(
                    id='x-variable',
                    options=[{'label': col, 'value': col} for col in df.columns],
                    placeholder="Select X variable"
                ),
                dcc.Dropdown(
                    id='y-variable',
                    options=[{'label': col, 'value': col} for col in df.columns],
                    placeholder="Select Y variable"
                ),
                dcc.Dropdown(
                    id='color-variable',
                    options=[{'label': col, 'value': col} for col in df.columns if df[col].dtype == 'object'],
                    placeholder="Select color variable"
                ),
                html.Div(id='scatter-plots-container')
            ]),
            html.Div(id='histogram-container'),
            html.Div(id='box-plot-container')
        ])
    ########### Tab 3
    elif tab == 'tab-3':
        return html.Div([
            html.Div([
                dcc.Dropdown(
                    id='variables',
                    options=[{'label': col, 'value': col} for col in df.columns],
                    multi=True,
                    placeholder="Select variables"
                ),
                dcc.Dropdown(
                    id='dependent-variable',
                    options=[{'label': col, 'value': col} for col in df.columns],
                    placeholder="Select dependent variable"
                ),
                html.Button('Run Regression', id='run-regression-button', n_clicks=0),
                dash_table.DataTable(
                    id='regression-results',


                    style_cell={'backgroundColor': '#111111', 'textAlign': 'center', 'fontSize': 14,
                                'font-style': 'normal', 'color': 'white'},
                    sort_action="native"
                )
            ]),
            html.Div(id='fitted-scatter'),
        ])


# Define the callback for generating scatter plots
@app.callback(
    Output('scatter-plots-container', 'children'),
    [Input('x-variable', 'value'),
     Input('y-variable', 'value'),
     Input('color-variable', 'value')]
)
def generate_scatter_plots(x_var, y_var, color_var):
    scatter_plots = []

    if x_var and y_var:
        if not color_var:
            fig = px.scatter(df, x=x_var, y=y_var, title=f'Relationship of {x_var} and  {y_var}')
        else:
            fig = px.scatter(df, x=x_var, y=y_var, color=color_var, title=f'Relationship of {x_var} and {y_var},' \
                                                                            f'separated by {color_var}')

        fig.update_layout(showlegend=True)
        scatter_plots.append(dcc.Graph(figure=fig))

    return scatter_plots

# Define the callback for generating histogram
@app.callback(
    Output('histogram-container', 'children'),
    [Input('x-variable', 'value')]
)
def generate_histogram(x_var):
    if x_var:
        fig = px.histogram(df, x=x_var, title=f"Histogram of {x_var}")
        return dcc.Graph(figure=fig)
    else:
        return None


# Define the callback for generating histogram
@app.callback(
    Output('box-plot-container', 'children'),
    [Input('x-variable', 'value'),
     Input('color-variable', 'value')]
)
def generate_boxplot(x_var, color_var):
    if color_var:
        fig = px.box(df, x=color_var, y=x_var, color=color_var, title=f'Boxplot of {x_var} separated by {color_var}')
        return dcc.Graph(figure=fig)
    else:
        return None

@app.callback(
    Output('regression-results', 'data'),
    [Input('run-regression-button', 'n_clicks')],
    [dash.dependencies.State('variables', 'value'),
     dash.dependencies.State('dependent-variable', 'value')]
)
def run_regression(n_clicks, independent_vars, dependent_var):
    if n_clicks > 0 and independent_vars and dependent_var:
        X = df[independent_vars]
        X = sm.add_constant(X)
        y = df[dependent_var]

        model = sm.OLS(y, X).fit()

        coefficients = model.params
        p_values = model.pvalues
        global r_squared
        r_squared = model.rsquared
        fitted_values = model.fittedvalues

        results = pd.DataFrame({
            'Variable': X.columns,
            'Coefficient': coefficients,
            'P-value': p_values
        })

        results['P-value'] = results['P-value'].apply(lambda x: "{:.4f}".format(x))
        global plot_data

        plot_data = pd.DataFrame({"Actual Values": y, "Fitted Values": fitted_values})

        return results.to_dict('records')
    else:
        return []

@app.callback(
    Output('fitted-scatter', 'children'),
    [Input('run-regression-button', 'n_clicks')],
    [dash.dependencies.State('variables', 'value'),
     dash.dependencies.State('dependent-variable', 'value')]
)

def fitted_plot(n_clicks, independent_vars, dependent_var):
    if n_clicks > 0 and independent_vars and dependent_var:
        X = df[independent_vars]
        X = sm.add_constant(X)
        y = df[dependent_var]

        model = sm.OLS(y, X).fit()


        global r_squared
        r_squared = np.round(model.rsquared, 3)
        fitted_values = model.fittedvalues

        plot_data = pd.DataFrame({"Actual Values": y, "Fitted Values": fitted_values})
        fig = px.scatter(plot_data, x="Actual Values", y="Fitted Values", title=f'R squared is equal to {100*r_squared} %')
        return dcc.Graph(figure=fig)


    else:
        return None

if __name__ == '__main__':
    app.run(debug=True)

